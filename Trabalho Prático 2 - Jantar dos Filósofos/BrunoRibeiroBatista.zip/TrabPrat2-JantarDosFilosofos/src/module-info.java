/**
 * 
 */
/**
 * 
 */
module trabPrat2 {
	requires java.desktop;
}